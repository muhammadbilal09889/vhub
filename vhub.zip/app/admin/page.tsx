'use client';
import React, { useEffect, useState } from 'react';

function InviteSection(){
  const [list, setList] = useState<any[]>([]);
  const [maxUses, setMaxUses] = useState(1);
  async function load(){ const r = await fetch('/api/admin/invites').then(r=>r.json()); setList(r.invites||[]); }
  useEffect(()=>{ load(); },[]);
  async function create(){ await fetch('/api/admin/invites', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ maxUses }) }); await load(); }
  async function toggle(id:string, active:boolean){ await fetch('/api/admin/invites', { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id, active }) }); await load(); }
  return (<section className="space-y-2">
    <div className="font-semibold">Invite Codes</div>
    <div className="flex gap-2 items-center">
      <input type="number" className="w-40" value={maxUses} onChange={e=>setMaxUses(Number(e.target.value||1))} />
      <button onClick={create} className="px-3 py-2 rounded btn-brand">Create Invite</button>
    </div>
    <div className="overflow-auto border rounded">
      <table className="min-w-full text-sm">
        <thead className="bg-white"><tr><th className="p-2">Code</th><th className="p-2">Uses</th><th className="p-2">Active</th><th className="p-2">Actions</th></tr></thead>
        <tbody>{list.map((i:any)=> (<tr key={i.id} className="border-t"><td className="p-2">{i.code}</td><td className="p-2">{i.usedCount}/{i.maxUses}</td><td className="p-2">{i.active? 'Yes':'No'}</td><td className="p-2"><button onClick={()=>toggle(i.id,!i.active)} className="px-3 py-1 rounded border">{i.active?'Disable':'Enable'}</button></td></tr>))}</tbody>
      </table>
    </div>
  </section>);
}

export default function Admin(){
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  async function loadAll(){
    setLoading(true);
  }
  useEffect(()=>{
    (async()=>{
      const s = await fetch('/api/admin/stats').then(r=>r.json());
      const u = await fetch('/api/admin/users').then(r=>r.json());
      const w = await fetch('/api/admin/withdrawals').then(r=>r.json());
      setStats(s); setUsers(u.users||[]); setWithdrawals(w.withdrawals||[]); setLoading(false);
    })();
  },[]);

  return (
    <main className="max-w-6xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Admin Panel</h1>
      {loading && <div>Loading...</div>}

      {stats && (<section className="grid md:grid-cols-3 gap-4">
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Total Users</div><div className="text-2xl font-semibold">{stats.users}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Revenue (Joinings)</div><div className="text-2xl font-semibold">Rs. {stats.revenue}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Commissions / Withdrawals</div><div className="text-2xl font-semibold">Rs. {stats.commissions} / Rs. {stats.withdrawals}</div></div>
      </section>)}

      <section className="space-y-2">
        <div className="font-semibold">Users</div>
        <div className="overflow-auto border rounded">
          <table className="min-w-full text-sm">
            <thead className="bg-white"><tr><th className="p-2">Name</th><th className="p-2">Email</th><th className="p-2">Sponsor</th><th className="p-2">Left</th><th className="p-2">Right</th><th className="p-2">Joined</th></tr></thead>
            <tbody>{users.map((u:any)=> (<tr key={u.id} className="border-t"><td className="p-2">{u.name}</td><td className="p-2">{u.email}</td><td className="p-2">{u.sponsorId? u.sponsorId.slice(0,6):'—'}</td><td className="p-2">{u.leftChildId? u.leftChildId.slice(0,6):'—'}</td><td className="p-2">{u.rightChildId? u.rightChildId.slice(0,6):'—'}</td><td className="p-2">{new Date(u.joinedAt).toLocaleString()}</td></tr>))}</tbody>
          </table>
        </div>
      </section>

      <section className="space-y-2">
        <div className="font-semibold">Withdrawals</div>
        <div className="overflow-auto border rounded">
          <table className="min-w-full text-sm">
            <thead className="bg-white"><tr><th className="p-2">User</th><th className="p-2">Amount</th><th className="p-2">Method</th><th className="p-2">Status</th></tr></thead>
            <tbody>{withdrawals.map((w:any)=> (<tr key={w.id} className="border-t"><td className="p-2">{w.userId.slice(0,6)}</td><td className="p-2">Rs. {w.amount}</td><td className="p-2">{w.method}</td><td className="p-2">{w.status}</td></tr>))}</tbody>
          </table>
        </div>
      </section>

      <InviteSection />
    </main>
  );
}
