import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';

export async function GET(){
  const list = await prisma.inviteCode.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json({ ok:true, invites: list });
}
export async function POST(req: NextRequest){
  const { maxUses=1, expiresAt, active=true } = await req.json();
  const code = 'INV-' + Math.random().toString(36).slice(2,8).toUpperCase();
  const inv = await prisma.inviteCode.create({ data: { code, maxUses, expiresAt: expiresAt ? new Date(expiresAt) : null, active } });
  return NextResponse.json({ ok:true, invite: inv });
}
export async function PUT(req: NextRequest){
  const { id, active } = await req.json();
  const inv = await prisma.inviteCode.update({ where: { id }, data: { active } });
  return NextResponse.json({ ok:true, invite: inv });
}
