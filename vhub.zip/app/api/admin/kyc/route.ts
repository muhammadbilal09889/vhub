import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';

export async function GET(){
  const list = await prisma.kycDocument.findMany({ orderBy:{ createdAt:'desc' } });
  return NextResponse.json({ ok:true, kycs:list });
}

export async function POST(req: NextRequest){
  const { id, approve, notes } = await req.json();
  const status = approve ? 'APPROVED' : 'REJECTED';
  const doc = await prisma.kycDocument.update({ where:{ id }, data:{ status, reviewedAt: new Date(), notes } });
  return NextResponse.json({ ok:true, doc });
}
