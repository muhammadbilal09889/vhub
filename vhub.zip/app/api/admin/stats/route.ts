import { NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';

export async function GET(){
  const users = await prisma.user.count();
  const paidJoinings = await prisma.transaction.aggregate({ _sum: { amount: true }, where: { type: 'JOINING', status: 'SUCCESS' } });
  const commissions = await prisma.transaction.aggregate({ _sum: { amount: true }, where: { type: 'COMMISSION', status: 'SUCCESS' } });
  const withdrawals = await prisma.transaction.aggregate({ _sum: { amount: true }, where: { type: 'WITHDRAWAL', status: 'SUCCESS' } });
  return NextResponse.json({ users, revenue: paidJoinings._sum.amount || 0, commissions: commissions._sum.amount || 0, withdrawals: withdrawals._sum.amount || 0 });
}
