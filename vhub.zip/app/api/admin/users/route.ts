import { NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';

export async function GET(){
  const users = await prisma.user.findMany({ select: { id:true, name:true, email:true, sponsorId:true, leftChildId:true, rightChildId:true, joinedAt:true, isBlocked:true } });
  return NextResponse.json({ users });
}
