import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { comparePassword, signJwt } from '@/src/lib/auth';
import { z } from 'zod';

const Body = z.object({ email: z.string().email(), password: z.string() });
export async function POST(req: NextRequest){
  const body = Body.parse(await req.json());
  const user = await prisma.user.findUnique({ where: { email: body.email } });
  if (!user) return NextResponse.json({ ok:false, error:'User not found' }, { status:404 });
  const ok = await comparePassword(body.password, user.passwordHash);
  if (!ok) return NextResponse.json({ ok:false, error:'Invalid credentials' }, { status:401 });
  const token = signJwt({ sub: user.id, email: user.email });
  return NextResponse.json({ ok:true, token });
}
