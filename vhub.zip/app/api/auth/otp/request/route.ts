import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { sendMail } from '@/src/lib/mailer';
import { z } from 'zod';

const Body = z.object({ email: z.string().email(), purpose: z.string().default('LOGIN') });

export async function POST(req: NextRequest){
  const { email, purpose } = Body.parse(await req.json());
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return NextResponse.json({ ok:false, error:'User not found' }, { status:404 });
  const code = String(Math.floor(100000 + Math.random()*900000));
  const expiresAt = new Date(Date.now() + 5*60*1000);
  await prisma.otpCode.create({ data: { userId: user.id, code, purpose, expiresAt } });
  await sendMail(email, 'Your OTP Code', `<p>OTP: <b>${code}</b> (valid 5 min)</p>`);
  return NextResponse.json({ ok:true });
}
