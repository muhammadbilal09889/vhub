import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { signJwt } from '@/src/lib/auth';
import { z } from 'zod';

const Body = z.object({ email: z.string().email(), code: z.string().min(4), purpose: z.string().default('LOGIN') });

export async function POST(req: NextRequest){
  const { email, code, purpose } = Body.parse(await req.json());
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return NextResponse.json({ ok:false, error:'User not found' }, { status:404 });
  const found = await prisma.otpCode.findFirst({ where: { userId: user.id, code, purpose, used:false, expiresAt: { gte: new Date() } }, orderBy:{ createdAt:'desc' } });
  if (!found) return NextResponse.json({ ok:false, error:'Invalid/expired code' }, { status:400 });
  await prisma.otpCode.update({ where: { id: found.id }, data: { used:true } });
  const token = signJwt({ sub: user.id, email: user.email });
  return NextResponse.json({ ok:true, token });
}
