import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { hashPassword, signJwt } from '@/src/lib/auth';
import { z } from 'zod';
import { placeMember } from '@/src/lib/binary';

const Body = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  sponsorId: z.string().uuid().optional(),
  side: z.enum(['left','right']).optional(),
  inviteCode: z.string().min(4),
});

export async function POST(req: NextRequest){
  try {
    const body = Body.parse(await req.json());
    const inv = await prisma.inviteCode.findUnique({ where: { code: body.inviteCode } });
    if (!inv || !inv.active) return NextResponse.json({ ok:false, error:'Invite invalid' }, { status:400 });
    if (inv.expiresAt && inv.expiresAt < new Date()) return NextResponse.json({ ok:false, error:'Invite expired' }, { status:400 });
    if (inv.usedCount >= inv.maxUses) return NextResponse.json({ ok:false, error:'Invite limit reached' }, { status:400 });

    const exists = await prisma.user.findUnique({ where: { email: body.email } });
    if (exists) return NextResponse.json({ ok:false, error:'Email already exists' }, { status:400 });

    const passwordHash = await hashPassword(body.password);
    const user = await prisma.user.create({ data: { name: body.name, email: body.email, passwordHash, sponsorId: body.sponsorId || null } });

    if (body.sponsorId && body.side) await placeMember({ sponsorId: body.sponsorId, side: body.side, newUserId: user.id });

    await prisma.inviteCode.update({ where: { id: inv.id }, data: { usedCount: { increment: 1 } } });

    const token = signJwt({ sub: user.id, email: user.email });
    return NextResponse.json({ ok:true, token, user: { id: user.id, name: user.name, email: user.email } });
  } catch (e:any) { return NextResponse.json({ ok:false, error:e.message }, { status:400 }); }
}
