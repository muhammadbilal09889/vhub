import { NextRequest, NextResponse } from 'next/server';
import { getUserIdFromAuthHeader } from '@/src/lib/jwt-session';
import { getPresignedPutUrl } from '@/src/lib/s3';

export async function POST(req: NextRequest){
  const userId = getUserIdFromAuthHeader(req.headers);
  if (!userId) return NextResponse.json({ ok:false, error:'Unauthorized' }, { status:401 });
  const { type, contentType } = await req.json();
  const ext = contentType === 'image/png' ? 'png' : contentType === 'image/jpeg' ? 'jpg' : 'bin';
  const key = `kyc/${userId}/${Date.now()}_${type}.${ext}`;
  const url = await getPresignedPutUrl(key, contentType);
  return NextResponse.json({ ok:true, key, url });
}
