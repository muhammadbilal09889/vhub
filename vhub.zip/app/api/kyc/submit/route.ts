import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { getUserIdFromAuthHeader } from '@/src/lib/jwt-session';

export async function POST(req: NextRequest){
  const userId = getUserIdFromAuthHeader(req.headers);
  if (!userId) return NextResponse.json({ ok:false, error:'Unauthorized' }, { status:401 });
  const { type, storageKey, url } = await req.json();
  const doc = await prisma.kycDocument.create({ data: { userId, type, storageKey, url } });
  return NextResponse.json({ ok:true, doc });
}
