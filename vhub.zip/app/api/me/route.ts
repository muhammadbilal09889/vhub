import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { getUserIdFromAuthHeader } from '@/src/lib/jwt-session';
import { getAvailableBalance } from '@/src/lib/balance';

export async function GET(req: NextRequest){
  const userId = getUserIdFromAuthHeader(req.headers);
  if (!userId) return NextResponse.json({ ok:false, error:'Unauthorized' }, { status:401 });
  const user = await prisma.user.findUnique({ where:{ id:userId }, select:{ id:true, name:true, email:true, sponsorId:true, leftChildId:true, rightChildId:true, joinedAt:true } });
  if (!user) return NextResponse.json({ ok:false, error:'Not found' }, { status:404 });
  const available = await getAvailableBalance(userId);
  const commissions = await prisma.transaction.aggregate({ _sum:{ amount:true }, where:{ userId, type:'COMMISSION', status:'SUCCESS' } });
  const withdrawals = await prisma.transaction.aggregate({ _sum:{ amount:true }, where:{ userId, type:'WITHDRAWAL', status:'SUCCESS' } });
  return NextResponse.json({ ok:true, user, balances:{ available, earned: commissions._sum.amount||0, paid: withdrawals._sum.amount||0 } });
}
