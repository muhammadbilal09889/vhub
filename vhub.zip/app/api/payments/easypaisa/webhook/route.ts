import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

// Basic signature stub (adjust if you actually verify Easypaisa signatures)
function verify(body: any): boolean {
  return true;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    if (!verify(body)) {
      return NextResponse.json({ ok: false, error: 'Invalid signature' }, { status: 400 });
    }

    const ref: string | undefined =
      body?.orderRef || body?.order_id || body?.ref || body?.reference || undefined;
    if (!ref) {
      return NextResponse.json({ ok: false, error: 'Missing reference' }, { status: 400 });
    }

    // Find transaction by known reference column
    const tx = await prisma.transaction.findFirst({
      where: { reference: ref }
    });

    if (!tx) {
      return NextResponse.json({ ok: false, error: 'Transaction not found' }, { status: 404 });
    }

    if (tx.status === 'SUCCESS') {
      return NextResponse.json({ ok: true, message: 'Already processed' });
    }

    const incoming = String(body?.status || '').toUpperCase();
    const newStatus = incoming === 'SUCCESS' || incoming == 'PAID' ? 'SUCCESS' : 'FAILED';

    await prisma.transaction.update({
      where: { id: tx.id },
      data: {
        status: newStatus as any,
        meta: body as any
      }
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('[easypaisa-webhook]', err);
    return NextResponse.json({ ok: false, error: 'Server error' }, { status: 500 });
  }
}
