import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { verifyJazzCashSignature } from '@/src/lib/payments';

export async function POST(req: NextRequest){
  const body = await req.json();
  if (!verifyJazzCashSignature(body)) return NextResponse.json({ ok:false, error:'Bad signature' }, { status:400 });
  // Auto-commission: buyer + referrer 10% on success
  if (updated.status === 'SUCCESS'){
    const meta: any = updated.meta || {};
    const buyerId = meta.buyerId || updated.userId;
    const referrerId = meta.referrerId;
    const baseAmount = meta.baseAmountPKR || updated.amount;
    const { creditCommissionPKR } = await import('@/src/lib/commission');
    if (buyerId) await creditCommissionPKR(buyerId, baseAmount, 'VSTORE_BUY', 10);
    if (referrerId) await creditCommissionPKR(referrerId, baseAmount, 'REFERRAL', 10);
  }
  return NextResponse.json({ ok:true });;
  const ref = body.pp_TxnRefNo;
  const tx = await prisma.transaction.findUnique({ where: { reference: ref } });
  if (!tx) return NextResponse.json({ ok:false, error:'Tx not found' }, { status:404 });
  if (tx.status === 'SUCCESS') return NextResponse.json({ ok:true, message:'Already processed' });
  const updated = await prisma.transaction.update({ where: { id: tx.id }, data: { status: body.pp_ResponseCode === '000' ? 'SUCCESS' : 'FAILED', meta: body } });
  return NextResponse.json({ ok:true });
}
