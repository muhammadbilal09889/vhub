import { NextRequest, NextResponse } from 'next/server';
import { signJazzCash, signEasypaisa } from '@/src/lib/payments-live';

export async function POST(req: NextRequest){
  const { method, amountRs, orderRef, returnUrl } = await req.json();
  if (!['JAZZCASH','EASYPAISA'].includes(method)) return NextResponse.json({ ok:false, error:'Unsupported method' }, { status:400 });

  if (method === 'JAZZCASH'){
    const params = signJazzCash({
      pp_Version: '1.1',
      pp_TxnType: 'MWALLET',
      pp_Language: 'EN',
      pp_MerchantID: process.env.JAZZCASH_MERCHANT_ID!,
      pp_Password: process.env.JAZZCASH_PASSWORD!,
      pp_TxnRefNo: orderRef,
      pp_Amount: String(Number(amountRs) * 100),
      pp_TxnCurrency: 'PKR',
      pp_TxnDateTime: new Date().toISOString().replace(/[-:TZ.]/g,'').slice(0,14),
      pp_BillReference: orderRef,
      pp_Description: 'V Hub Joining',
      pp_ReturnURL: returnUrl,
    }, process.env.JAZZCASH_INTEGRITY_SALT!);
    return NextResponse.json({ ok:true, gateway:'JAZZCASH', params });
  }

  if (method === 'EASYPAISA'){
    const params = signEasypaisa({
      storeId: process.env.EASYPAISA_STORE_ID!,
      amount: Number(amountRs).toFixed(2),
      orderRef,
      postBackURL: returnUrl,
      expiry: new Date(Date.now() + 10*60*1000).toISOString(),
      autoRedirect: 'YES'
    }, process.env.EASYPAISA_SECRET!);
    return NextResponse.json({ ok:true, gateway:'EASYPAISA', params });
  }
}
