import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { computeEarningsFor } from '@/src/lib/binary';

export async function POST(req: NextRequest){
  const { userId } = await req.json();
  const { total, perLevel } = await computeEarningsFor(userId);
  if (total <= 0) return NextResponse.json({ ok:true, total:0, perLevel });
  await prisma.transaction.create({ data: { userId, type: 'COMMISSION', amount: total, status: 'SUCCESS', meta: { perLevel } } });
  return NextResponse.json({ ok:true, total, perLevel });
}
