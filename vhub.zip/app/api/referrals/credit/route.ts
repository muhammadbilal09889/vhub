import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { z } from 'zod';

/**
 * Credits 10% to the referrer's wallet when their link is used for a purchase/join.
 * Body: { referrerId: string (uuid), amount: number }  // amount in PKR that the referred user paid
 */
const Body = z.object({
  referrerId: z.string().uuid(),
  amount: z.number().positive()
});

export async function POST(req: NextRequest){
  const body = Body.parse(await req.json());
  const commission = Math.round(body.amount * 0.10); // 10%
  const tx = await prisma.transaction.create({
    data: {
      userId: body.referrerId,
      type: 'COMMISSION',
      status: 'SUCCESS',
      amount: commission,
      meta: { source: 'REFERRAL', baseAmountPKR: body.amount, percent: 10 }
    }
  });
  return NextResponse.json({ ok:true, commissionPKR: commission, tx });
}
