import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';

function toDate(s?: string){ return s ? new Date(s) : undefined; }

export async function GET(req: NextRequest){
  const { searchParams } = new URL(req.url);
  const from = toDate(searchParams.get('from')||'');
  const to = toDate(searchParams.get('to')||'');

  const users = await prisma.user.findMany({ where: { joinedAt: from && to ? { gte: from, lte: to } : undefined }, select: { joinedAt: true } });
  const joinsByDay: Record<string, number> = {};
  users.forEach(u=>{ const d = new Date(u.joinedAt).toISOString().slice(0,10); joinsByDay[d] = (joinsByDay[d]||0)+1; });

  const tx = await prisma.transaction.findMany({ where: { createdAt: from && to ? { gte: from, lte: to } : undefined, status: 'SUCCESS' }, select: { createdAt:true, type:true, amount:true } });
  const commissionsByDay: Record<string, number> = {}; const withdrawalsByDay: Record<string, number> = {};
  tx.forEach(t=>{ const d = new Date(t.createdAt).toISOString().slice(0,10); if (t.type==='COMMISSION') commissionsByDay[d]=(commissionsByDay[d]||0)+t.amount; if (t.type==='WITHDRAWAL') withdrawalsByDay[d]=(withdrawalsByDay[d]||0)+t.amount; });

  return NextResponse.json({ ok:true, joinsByDay, commissionsByDay, withdrawalsByDay });
}
