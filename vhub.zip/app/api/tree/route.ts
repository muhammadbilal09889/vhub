import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { getUserIdFromAuthHeader } from '@/src/lib/jwt-session';

export async function GET(req: NextRequest){
  const userId = getUserIdFromAuthHeader(req.headers);
  if (!userId) return NextResponse.json({ ok:false, error:'Unauthorized' }, { status:401 });

  async function getUser(id: string){
    return prisma.user.findUnique({ where:{ id }, select:{ id:true, name:true, leftChildId:true, rightChildId:true } });
  }
  const queue: Array<{ id:string, depth:number }> = [{ id:userId, depth:0 }];
  const nodes: Record<string, any> = {};
  while(queue.length){
    const { id, depth } = queue.shift()!;
    const u = await getUser(id);
    if (!u) continue;
    nodes[id] = { ...u, depth };
    if (u.leftChildId) queue.push({ id: u.leftChildId, depth: depth+1 });
    if (u.rightChildId) queue.push({ id: u.rightChildId, depth: depth+1 });
    if (Object.keys(nodes).length > 127) break;
  }
  return NextResponse.json({ ok:true, root: userId, nodes });
}
