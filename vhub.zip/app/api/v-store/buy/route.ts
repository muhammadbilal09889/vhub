import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { z } from 'zod';

/**
 * Credits 10% of product price to the buyer's wallet.
 * Currency: PKR
 * Body: { userId: string (uuid), price: number }  // price in PKR
 */
const Body = z.object({
  userId: z.string().uuid(),
  price: z.number().positive()
});

export async function POST(req: NextRequest){
  const body = Body.parse(await req.json());
  const commission = Math.round(body.price * 0.10); // 10% in PKR (rounded)
  const tx = await prisma.transaction.create({
    data: {
      userId: body.userId,
      type: 'COMMISSION',
      status: 'SUCCESS',
      amount: commission,
      meta: { source: 'VSTORE_BUY', pricePKR: body.price, percent: 10 }
    }
  });
  return NextResponse.json({ ok:true, commissionPKR: commission, tx });
}
