import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { z } from 'zod';

/**
 * Create a pending V Store order payment "Transaction" that webhooks can update later.
 * - Currency: PKR
 * - Returns a unique orderRef to be used with payment session and matched in webhooks.
 */
const Body = z.object({
  buyerId: z.string().uuid(),
  amountPKR: z.number().positive(),
  method: z.enum(['JAZZCASH','EASYPAISA']),
  referrerId: z.string().uuid().optional().nullable()
});

function genRef(prefix='ORD'){
  const rnd = Math.random().toString(36).slice(2,8).toUpperCase();
  return `${prefix}-${Date.now()}-${rnd}`;
}

export async function POST(req: NextRequest){
  const body = Body.parse(await req.json());
  const orderRef = genRef();
  const tx = await prisma.transaction.create({
    data: {
      userId: body.buyerId,
      type: 'JOINING', // NOTE: Using JOINING as a generic incoming payment; add PURCHASE later if you extend enum.
      amount: Math.round(body.amountPKR),
      status: 'PENDING',
      method: body.method as any,
      reference: orderRef,
      meta: {
        purpose: 'VSTORE_ORDER',
        buyerId: body.buyerId,
        referrerId: body.referrerId || null,
        baseAmountPKR: Math.round(body.amountPKR)
      }
    }
  });
  return NextResponse.json({ ok:true, orderRef, txId: tx.id, amountPKR: tx.amount, method: body.method });
}
