import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';

export async function POST(req: NextRequest){
  const { withdrawalId, approve } = await req.json();
  const wd = await prisma.withdrawal.findUnique({ where: { id: withdrawalId } });
  if (!wd) return NextResponse.json({ ok:false, error:'Not found' }, { status:404 });
  if (!approve){
    await prisma.withdrawal.update({ where: { id: wd.id }, data: { status: 'REJECTED', processedAt: new Date() } });
    return NextResponse.json({ ok:true, status:'REJECTED' });
  }
  await prisma.withdrawal.update({ where: { id: wd.id }, data: { status: 'PAID', processedAt: new Date() } });
  await prisma.transaction.create({ data: { userId: wd.userId, type: 'WITHDRAWAL', amount: wd.amount, status: 'SUCCESS', method: wd.method, meta: { withdrawalId: wd.id } } });
  return NextResponse.json({ ok:true, status:'PAID' });
}
