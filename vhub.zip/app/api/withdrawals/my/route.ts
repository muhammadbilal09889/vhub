import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { getUserIdFromAuthHeader } from '@/src/lib/jwt-session';

export async function GET(req: NextRequest){
  const userId = getUserIdFromAuthHeader(req.headers);
  if (!userId) return NextResponse.json({ ok:false, error:'Unauthorized' }, { status:401 });
  const list = await prisma.withdrawal.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  return NextResponse.json({ ok:true, withdrawals: list });
}
