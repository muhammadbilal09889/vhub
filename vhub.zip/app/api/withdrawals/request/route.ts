import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/src/lib/db';
import { getAvailableBalance } from '@/src/lib/balance';
import { z } from 'zod';

const Body = z.object({ userId: z.string().uuid(), amount: z.number().int().positive(), method: z.enum(['JAZZCASH','EASYPAISA','BANK']), accountMeta: z.any().optional() });

export async function POST(req: NextRequest){
  const body = Body.parse(await req.json());
  const avail = await getAvailableBalance(body.userId);
  if (body.amount > avail) return NextResponse.json({ ok:false, error:'Balance kam hai' }, { status:400 });
  const wd = await prisma.withdrawal.create({ data: { userId: body.userId, amount: body.amount, method: body.method as any, accountMeta: body.accountMeta } });
  return NextResponse.json({ ok:true, withdrawal: wd, availableAfter: avail - body.amount });
}
