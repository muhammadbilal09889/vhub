'use client';
import React, { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';

export default function JoinPage(){
  const params = useSearchParams();
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [sponsorId, setSponsorId] = useState('');
  const [side, setSide] = useState<'left'|'right'>('left');
  const [msg, setMsg] = useState('');

  useEffect(()=>{
    const s = params.get('sponsor'); if (s) setSponsorId(s);
    const sd = params.get('side'); if (sd==='right') setSide('right');
    const c = params.get('code'); if (c) setInviteCode(c);
  }, [params]);

  async function submit(){
    setMsg('');
    const body = { name, email, password, sponsorId: sponsorId || undefined, side, inviteCode };
    const r = await fetch('/api/auth/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) }).then(r=>r.json());
    if (!r.ok) { setMsg(r.error || 'Error'); return; }
    router.push('/member');
  }

  return (
    <main className="max-w-xl mx-auto p-6 space-y-4">
      <h1 className="text-2xl font-bold">Join</h1>
      <div className="grid gap-2">
        <input className="border p-2 rounded" placeholder="Full Name" value={name} onChange={e=>setName(e.target.value)} />
        <input className="border p-2 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input type="password" className="border p-2 rounded" placeholder="Password (min 6)" value={password} onChange={e=>setPassword(e.target.value)} />
        <input className="border p-2 rounded" placeholder="Invite Code" value={inviteCode} onChange={e=>setInviteCode(e.target.value)} />
        <input className="border p-2 rounded" placeholder="Sponsor ID (optional)" value={sponsorId} onChange={e=>setSponsorId(e.target.value)} />
        <div className="flex gap-2">
          <button onClick={()=>setSide('left')} className={`px-3 py-2 rounded ${side==='left'?'btn-brand':'border'}`}>Left</button>
          <button onClick={()=>setSide('right')} className={`px-3 py-2 rounded ${side==='right'?'btn-brand':'border'}`}>Right</button>
        </div>
        <button onClick={submit} className="px-4 py-2 rounded btn-brand">Create Account</button>
        {msg && <div className="text-sm mt-1">{msg}</div>}
      </div>
      <div className="text-xs text-gray-600">Note: Joining ke sath genuine product/service provide karna laazmi hai.</div>
    </main>
  );
}
