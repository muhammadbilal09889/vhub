'use client';
import Link from 'next/link';
import { BRAND } from '@/src/brand';

function Section({ children, className='' }: any){ return <section className={`max-w-6xl mx-auto px-4 py-12 ${className}`}>{children}</section>; }

function Step({ n, title, desc }:{ n:number, title:string, desc:string }){
  return (<div className="rounded-2xl border bg-white p-6">
    <div className="text-sm text-gray-500">Step {n}</div>
    <div className="text-lg font-semibold">{title}</div>
    <div className="text-sm text-gray-600 mt-1">{desc}</div>
  </div>);
}
function Faq({ q, a }:{ q:string, a:string }){
  return (<div className="rounded-2xl border bg-white p-5">
    <div className="font-semibold">{q}</div>
    <div className="text-sm text-gray-600 mt-1">{a}</div>
  </div>);
}

export default function Landing(){
  return (
    <main className="bg-gradient-to-b from-white to-slate-50">
      <section
        className="relative"
        style={{ backgroundImage: "url('/bg-vhub.png')", backgroundSize: 'cover', backgroundPosition: 'top center' }}
      >
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 relative">
          <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(255,255,255,0.88) 0%, rgba(255,255,255,0.82) 40%, rgba(250,250,250,0.92) 100%)' }}></div>
          <div className="relative text-center">
            <div className="inline-block rounded-full px-3 py-1 text-xs border mb-3 bg-white/70">Official • V Hub</div>
            <h1 className="text-4xl font-extrabold" style={{ color: '#6D28D9' }}>Grow with V Hub</h1>
            <p className="mt-3 text-gray-600 max-w-2xl mx-auto">V Hub — binary plan platform with real products/services, secure payouts, and KYC.</p>
            <div className="mt-5 flex gap-3 justify-center">
              <a href="/join" className="px-5 py-3 rounded-xl text-white" style={{ background:'#6D28D9' }}>Join Now</a>
              <a href="/member" className="px-5 py-3 rounded-xl border">Go to Dashboard</a>
            </div>
          </div>
        </div>
      </section>
      <Section>
        <div className="inline-block rounded-full px-3 py-1 text-xs border mb-3">Official • {BRAND.shortName}</div>
        <h1 className="text-4xl font-extrabold" style={{ color: '#6D28D9' }}>Grow with V Hub</h1>
        <p className="mt-3 text-gray-600 max-w-2xl mx-auto">{BRAND.description}</p>
        <div className="mt-5 flex gap-3 justify-center">
          <Link href="/join" className="px-5 py-3 rounded-xl text-white" style={{ background:'#6D28D9' }}>Join Now</Link>
          <Link href="/member" className="px-5 py-3 rounded-xl border">Go to Dashboard</Link>
        </div>
        <div className="mt-8 grid md:grid-cols-4 gap-4">
          {BRAND.features.map((f, i)=> (
            <div key={i} className="rounded-2xl border bg-white p-5 text-left">
              <div className="font-semibold" style={{ color:'#6D28D9' }}>{f.title}</div>
              <div className="text-sm text-gray-600 mt-1">{f.desc}</div>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <h2 className="text-2xl font-bold mb-3">How it works</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <Step n={1} title="Join & Verify" desc="Sign up with invite code, complete KYC." />
          <Step n={2} title="Place Left & Right" desc="Add 2 members (left/right), they repeat the same." />
          <Step n={3} title="Earn & Withdraw" desc="Level payouts accrue; withdraw via JazzCash/Easypaisa." />
        </div>
      </Section>

      <Section>
        <h2 className="text-2xl font-bold mb-3">Pricing</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {BRAND.pricing.map((p, i)=> (
            <div key={i} className="rounded-2xl border bg-white p-6">
              <div className="text-lg font-semibold" style={{ color:'#6D28D9' }}>{p.name}</div>
              <div className="text-3xl font-extrabold mt-1">{p.price}</div>
              <ul className="mt-3 text-sm text-gray-600 list-disc pl-5 space-y-1">
                {p.bullets.map((b, j)=> <li key={j}>{b}</li>)}
              </ul>
              <div className="mt-4">
                <Link href="/join" className="px-4 py-2 rounded-xl text-white" style={{ background:'#10B981' }}>Get Started</Link>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <h2 className="text-2xl font-bold mb-3">FAQs</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <Faq q="Kya joining fee ke sath product milta hai?" a="Haan — legal compliance ke liye har joining ke sath genuine product/service bundle hota hai." />
          <Faq q="Withdrawals kaise hotay hain?" a="Member dashboard se request; admin approval ke baad JazzCash/Easypaisa payout." />
          <Faq q="KYC kyu zaroori hai?" a="Fraud prevention & compliance ke liye CNIC/selfie docs verify kiye jatay hain." />
          <Faq q="Invite code kahan se milega?" a="Admin ya aapke sponsor se. Invite-only signup anti-fraud ke liye lagaya gaya hai." />
        </div>
        <div className="mt-6 text-center">
          <Link href="/join" className="px-5 py-3 rounded-xl text-white" style={{ background:'#6D28D9' }}>Join V Hub</Link>
        </div>
      </Section>

      <Section className="text-center text-xs text-gray-500">
        © {new Date().getFullYear()} V Hub. Please read our <a href="/legal/terms" className="link-brand">Terms</a> & <a className="link-brand" href="/legal/refund">Refunds</a>.
      </Section>
    </main>
  );
}
