import './globals.css';
import { I18nProvider } from '@/src/i18n/ctx';
import { BRAND } from '@/src/brand';

export const metadata = {
  metadataBase: new URL(BRAND.url),
  title: `${BRAND.name} — MLM Dashboard`,
  description: BRAND.description,
  openGraph: {
    title: `${BRAND.name} — MLM Dashboard`,
    description: BRAND.description,
    url: BRAND.url,
    siteName: BRAND.name,
    images: [{ url: '/og-vstore.png', width: 1200, height: 630, alt: 'V Hub' }],
    type: 'website'
  },
  twitter: {
    card: 'summary_large_image',
    site: '@vstore',
    title: `${BRAND.name} — MLM Dashboard`,
    description: BRAND.description,
    images: ['/og-vstore.png']
  },
  icons: { icon: '/favicon.ico' }
};

function BrandBar(){
  return (
    <div className="w-full border-b bg-white/80">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-xl" style={{ background: 'linear-gradient(90deg, #6D28D9, #10B981)' }}></div>
          <div className="font-bold" style={{ color:'#6D28D9' }}>V Hub</div>
          <span className="text-xs text-gray-500">binary plan platform</span>
        </div>
        <nav className="text-sm flex items-center gap-4">
          <a className="link-brand" href="/landing">Landing</a>
          <a className="link-brand" href="/join">Join</a>
          <a className="link-brand" href="/member">Member</a>
          <a className="link-brand" href="/admin">Admin</a>
          <a className="link-brand" href="/reports">Reports</a>
          <a className="link-brand" href="/v-store">V Store</a>
        </nav>
      </div>
    </div>
  );
}

export default function RootLayout({ children }:{ children: React.ReactNode }){
  return (
    <html lang="en">
      <body>
        <I18nProvider>
          <BrandBar />
          {children}
          <footer className="mt-12 border-t">
            <div className="max-w-6xl mx-auto px-4 py-6 text-xs text-gray-500 flex items-center justify-between">
              <div>© {new Date().getFullYear()} V Hub. All rights reserved.</div>
              <div className="flex gap-4">
                <a href="/legal/terms" className="link-brand">Terms</a>
                <a href="/legal/refund" className="link-brand">Refunds</a>
              </div>
            </div>
          </footer>
        </I18nProvider>
      </body>
    </html>
  );
}
