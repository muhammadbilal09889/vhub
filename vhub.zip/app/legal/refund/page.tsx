export default function Refund(){
  return (
    <main className="max-w-3xl mx-auto p-6 space-y-3">
      <h1 className="text-2xl font-bold">Refund Policy</h1>
      <p>Joining fee/product charges ke refund ke liye 7 din ke andar request submit karein. Approved refunds 5–10 business din me process kiye jate hain.</p>
      <ul className="list-disc pl-5 space-y-1 text-sm">
        <li>Digital content download/consume hone ke baad refund possible nahi.</li>
        <li>Compliance violation (fake referrals, chargebacks) par refund deny ho sakta hai.</li>
        <li>Gateway fees non-refundable ho sakti hai (JazzCash/Easypaisa policy).</li>
      </ul>
      <p className="text-xs text-gray-600">Note: Ye sample policy hai; local consumer laws ke mutabiq lawyer se verify karein.</p>
    </main>
  );
}
