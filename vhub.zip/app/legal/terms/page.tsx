export default function Terms(){
  return (
    <main className="max-w-3xl mx-auto p-6 space-y-3">
      <h1 className="text-2xl font-bold">Terms & Conditions</h1>
      <p>Ye platform sirf un users ke liye hai jo hamari policies se mutafiq hon. Product/service ke baghair sirf recruitment par commission mana hai.</p>
      <ul className="list-disc pl-5 space-y-1 text-sm">
        <li>Har joining ke sath product/service dena laazmi hai.</li>
        <li>Commissions sales/consumption pe based honge; recruitment-only payouts allow nahi.</li>
        <li>Fraud, multi-accounts, fake KYC par account block ho sakta hai.</li>
        <li>Taxes/FBR compliance user ki zimmedari bhi hai.</li>
      </ul>
      <p className="text-xs text-gray-600">Note: Ye sample T&Cs hain; apne lawyer se review karwa kar update karein.</p>
    </main>
  );
}
