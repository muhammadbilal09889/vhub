'use client';
import React, { useEffect, useMemo, useState } from 'react';

function TokenBox({ onToken }:{ onToken:(t:string)=>void }){
  const [tab, setTab] = useState<'PASSWORD'|'OTP'>('PASSWORD');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [msg, setMsg] = useState('');

  async function loginPass(){
    const r = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password }) }).then(r=>r.json());
    if (r.ok) onToken(r.token); else setMsg(r.error||'Error');
  }
  async function requestOtp(){
    const r = await fetch('/api/auth/otp/request', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, purpose:'LOGIN' }) }).then(r=>r.json());
    setMsg(r.ok? 'OTP bhej diya (email check karein)': (r.error||'Error'));
  }
  async function verifyOtp(){
    const r = await fetch('/api/auth/otp/verify', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, code: otp, purpose:'LOGIN' }) }).then(r=>r.json());
    if (r.ok) onToken(r.token); else setMsg(r.error||'Error');
  }

  return (<div className="border rounded p-4 space-y-3">
    <div className="flex gap-2 text-sm">
      <button className={`px-3 py-1 rounded ${tab==='PASSWORD'?'btn-brand text-white':'border'}`} onClick={()=>setTab('PASSWORD')}>Password</button>
      <button className={`px-3 py-1 rounded ${tab==='OTP'?'btn-brand text-white':'border'}`} onClick={()=>setTab('OTP')}>Email OTP</button>
    </div>

    {tab==='PASSWORD' && (<>
      <input className="w-full" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input type="password" className="w-full" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={loginPass} className="px-4 py-2 rounded btn-brand">Login</button>
    </>)}

    {tab==='OTP' && (<>
      <input className="w-full" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <div className="flex gap-2">
        <button onClick={requestOtp} className="px-3 py-2 rounded border">OTP Mangwain</button>
        <input className="flex-1" placeholder="OTP code" value={otp} onChange={e=>setOtp(e.target.value)} />
        <button onClick={verifyOtp} className="px-3 py-2 rounded btn-brand">Verify</button>
      </div>
    </>)}
    {msg && <div className="text-sm">{msg}</div>}
  </div>);
}

function Tree({ nodes, root }:{ nodes:any, root:string }){
  function Node({ id }:{ id:string }){
    const n = nodes[id]; if (!n) return null;
    return (<div className="flex flex-col items-center">
      <div className="rounded-xl border px-3 py-2 bg-white min-w-[160px] text-center">
        <div className="font-semibold">{n.name}</div>
        <div className="text-xs text-gray-500">{id.slice(0,6)}</div>
      </div>
      <div className="flex gap-8 mt-3">
        <div><div className="text-center text-xs mb-1">Left</div>{n.leftChildId? <Node id={n.leftChildId}/> : <div className="h-12 w-40 border rounded-xl text-xs flex items-center justify-center text-gray-500">Khaali</div>}</div>
        <div><div className="text-center text-xs mb-1">Right</div>{n.rightChildId? <Node id={n.rightChildId}/> : <div className="h-12 w-40 border rounded-xl text-xs flex items-center justify-center text-gray-500">Khaali</div>}</div>
      </div>
    </div>);
  }
  return <div className="flex justify-center overflow-x-auto"><Node id={root}/></div>;
}

export default function MemberArea(){
  const [token, setToken] = useState<string|null>(null);
  const [me, setMe] = useState<any>(null);
  const [tree, setTree] = useState<any>(null);
  const [wds, setWds] = useState<any[]>([]);
  const [meta, setMeta] = useState('{}');
  const [amount, setAmount] = useState(0);
  const [msg, setMsg] = useState('');

  async function load(){
    if (!token) return;
    const me = await fetch('/api/me', { headers:{ Authorization:`Bearer ${token}` } }).then(r=>r.json());
    const tree = await fetch('/api/tree', { headers:{ Authorization:`Bearer ${token}` } }).then(r=>r.json());
    const wds = await fetch('/api/withdrawals/my', { headers:{ Authorization:`Bearer ${token}` } }).then(r=>r.json());
    setMe(me); setTree(tree); setWds(wds.withdrawals||[]);
  }
  useEffect(()=>{ load(); },[token]);

  async function withdraw(){
    if (!token) return;
    const meResp = await fetch('/api/me', { headers:{ Authorization:`Bearer ${token}` } }).then(r=>r.json());
    const body = { userId: meResp.user.id, amount: Number(amount), method: 'JAZZCASH', accountMeta: JSON.parse(meta||'{}') };
    const r = await fetch('/api/withdrawals/request', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(body) }).then(r=>r.json());
    if (r.ok){ setMsg('Withdrawal request submit ✅'); load(); } else setMsg(r.error||'Error');
  }

  if (!token) return <main className="max-w-3xl mx-auto p-6"><TokenBox onToken={setToken}/></main>;

  const referralLink = me?.user?.id ? `${location.origin}/join?sponsor=${me.user.id}` : '';

  return (
    <main className="max-w-6xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Members Area</h1>

      {me && (<section className="grid md:grid-cols-3 gap-4">
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Aapka Naam</div><div className="text-xl font-semibold">{me.user.name}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Earnings (Total)</div><div className="text-2xl font-semibold">Rs. {me.balances.earned}</div></div>
        <div className="border rounded p-4"><div className="text-sm text-gray-600">Available (Withdraw)</div><div className="text-2xl font-semibold">Rs. {me.balances.available}</div></div>
      </section>)}

      <section className="border rounded p-4">
        <div className="font-semibold mb-2">Referral Link</div>
        <div className="flex gap-2 items-center">
          <input readOnly className="w-full" value={referralLink} />
          <button onClick={()=>navigator.clipboard.writeText(referralLink)} className="px-3 py-2 rounded border">Copy</button>
        </div>
      </section>

      <section className="border rounded p-4">
        <div className="font-semibold mb-3">Aapka Binary Tree</div>
        {tree?.ok ? <Tree nodes={tree.nodes} root={tree.root} /> : <div>Tree load nahi hua.</div>}
      </section>

      <section className="border rounded p-4">
        <div className="font-semibold mb-2">Withdrawal Request</div>
        <div className="grid md:grid-cols-3 gap-3">
          <input type="number" value={amount} onChange={e=>setAmount(Number(e.target.value||0))} />
          <input placeholder='Account Meta JSON' value={meta} onChange={e=>setMeta(e.target.value)} />
          <button onClick={withdraw} className="px-4 py-2 rounded btn-brand">Submit</button>
        </div>
        {msg && <div className="text-sm mt-2">{msg}</div>}
      </section>

      <section className="border rounded p-4">
        <div className="font-semibold mb-2">Aapki Withdrawals</div>
        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-white"><tr><th className="p-2">Date</th><th className="p-2">Amount</th><th className="p-2">Method</th><th className="p-2">Status</th></tr></thead>
            <tbody>{wds.map((w:any)=> (<tr key={w.id} className="border-t"><td className="p-2">{new Date(w.createdAt).toLocaleString()}</td><td className="p-2">Rs. {w.amount}</td><td className="p-2">{w.method}</td><td className="p-2">{w.status}</td></tr>))}</tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
