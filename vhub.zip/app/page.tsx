'use client';
import Link from 'next/link';
import { useI18n } from '@/src/i18n/ctx';
import { BRAND } from '@/src/brand';

export default function Home(){
  const { t } = useI18n();
  return (
    <main className="max-w-6xl mx-auto p-6 space-y-8">
      <section className="rounded-2xl border p-8 bg-white">
        <h1 className="text-3xl font-extrabold" style={{ color: '#6D28D9' }}>{BRAND.name}</h1>
        <p className="mt-2 text-gray-600 max-w-2xl">{BRAND.description}</p>
        <div className="mt-4 flex gap-3">
          <Link href="/landing" className="px-4 py-2 rounded-xl btn-brand">View Landing</Link>
          <Link href="/join" className="px-4 py-2 rounded-xl border">Join Now</Link>
        </div>
      </section>

      <section className="grid md:grid-cols-4 gap-4">
        <Link href="/admin" className="border rounded-xl p-4 hover:bg-gray-50">{t('adminPanel')}</Link>
        <Link href="/member" className="border rounded-xl p-4 hover:bg-gray-50">{t('membersArea')}</Link>
        <Link href="/reports" className="border rounded-xl p-4 hover:bg-gray-50">{t('reports')}</Link>
        <Link href="/legal/terms" className="border rounded-xl p-4 hover:bg-gray-50">{t('terms')}</Link>
      </section>
    </main>
  );
}
