'use client';
import React, { useState } from 'react';

export default function PaymentsDemo(){
  const [amount, setAmount] = useState(300);
  const [method, setMethod] = useState<'JAZZCASH'|'EASYPAISA'>('JAZZCASH');
  const [resp, setResp] = useState<any>(null);
  async function create(){
    const r = await fetch('/api/payments/session/live', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ method, amountRs: amount, orderRef: `ORD-${Date.now()}`, returnUrl: `${location.origin}/member` })
    }).then(r=>r.json());
    setResp(r);
  }
  return (
    <main className="max-w-xl mx-auto p-6 space-y-3">
      <h1 className="text-2xl font-bold">Payment Session (Live Params)</h1>
      <div className="grid md:grid-cols-3 gap-2">
        <input type="number" className="border p-2 rounded" value={amount} onChange={e=>setAmount(Number(e.target.value||300))} />
        <select className="border p-2 rounded" value={method} onChange={e=>setMethod(e.target.value as any)}>
          <option value="JAZZCASH">JazzCash</option>
          <option value="EASYPAISA">Easypaisa</option>
        </select>
        <button onClick={create} className="px-4 py-2 rounded btn-brand">Create</button>
      </div>
      {resp && <pre className="text-xs bg-white p-2 rounded overflow-auto">{JSON.stringify(resp, null, 2)}</pre>}
      <p className="text-xs text-gray-600">Confirm exact field names/order with your merchant docs.</p>
    </main>
  );
}
