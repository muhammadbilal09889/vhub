'use client';
import React, { useEffect, useMemo, useState } from 'react';
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function Reports(){
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [data, setData] = useState<any>(null);

  async function load(){
    const url = new URL('/api/reports/overview', window.location.origin);
    if (from) url.searchParams.set('from', from);
    if (to) url.searchParams.set('to', to);
    const r = await fetch(url).then(r=>r.json());
    setData(r);
  }
  useEffect(()=>{ load(); },[]);

  const rows = useMemo(()=>{
    if (!data?.ok) return [];
    const dates = new Set<string>([...Object.keys(data.joinsByDay||{}), ...Object.keys(data.commissionsByDay||{}), ...Object.keys(data.withdrawalsByDay||{})]);
    return [...dates].sort().map(d=>({ date:d, joins:data.joinsByDay[d]||0, commissions:data.commissionsByDay[d]||0, withdrawals:data.withdrawalsByDay[d]||0 }));
  },[data]);

  return (
    <main className="max-w-6xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Reports</h1>
      <div className="grid md:grid-cols-4 gap-3">
        <input type="date" className="border p-2 rounded" value={from} onChange={e=>setFrom(e.target.value)} />
        <input type="date" className="border p-2 rounded" value={to} onChange={e=>setTo(e.target.value)} />
        <button onClick={load} className="px-4 py-2 rounded btn-brand">Load</button>
      </div>

      <section className="border rounded p-4">
        <div className="font-semibold mb-2">Daily Joins</div>
        <div style={{ height: 256 }}>
          <ResponsiveContainer>
            <LineChart data={rows}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="date"/><YAxis/><Tooltip/><Line type="monotone" dataKey="joins"/></LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="border rounded p-4">
        <div className="font-semibold mb-2">Commissions vs Withdrawals</div>
        <div style={{ height: 256 }}>
          <ResponsiveContainer>
            <LineChart data={rows}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="date"/><YAxis/><Tooltip/><Line type="monotone" dataKey="commissions"/><Line type="monotone" dataKey="withdrawals"/></LineChart>
          </ResponsiveContainer>
        </div>
      </section>
    </main>
  );
}
