'use client';
export default function VStoreBuy(){
  const demo = [
    { id: 1, name: 'Matte Lipstick', price: 1200 },
    { id: 2, name: 'Hydrating Serum', price: 2600 },
    { id: 3, name: 'Kajal Pencil', price: 450 },
  ];
  return (
    <main className="max-w-6xl mx-auto p-6 space-y-8">
      <h1 className="text-2xl font-bold">Buy Products</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {demo.map(item => (
          <div key={item.id} className="border rounded-xl p-4 bg-white">
            <div className="font-semibold">{item.name}</div>
            <div className="text-sm text-gray-600 mt-1">PKR {item.price}</div>
            <button className="mt-3 px-3 py-2 rounded-xl btn-brand">Add to Cart</button>
          </div>
        ))}
      </div>
      <p className="text-xs text-gray-500">* Demo list. Hook to your DB/API later.</p>
    </main>
  );
}
