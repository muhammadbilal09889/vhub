'use client';
import Link from 'next/link';

export default function VStoreHome(){
  return (
    <main className="max-w-6xl mx-auto p-6 space-y-8">
      <section className="rounded-2xl border p-8 bg-white">
        <h1 className="text-2xl font-bold">V Store</h1>
        <p className="text-gray-600 mt-2">Members can buy and sell cosmetic products here.</p>
        <div className="mt-6 flex gap-3">
          <Link href="/v-store/buy" className="px-4 py-2 rounded-xl btn-brand">Buy Products</Link>
          <Link href="/v-store/sell" className="px-4 py-2 rounded-xl border">Sell a Product</Link>
        </div>
      </section>
    </main>
  );
}
