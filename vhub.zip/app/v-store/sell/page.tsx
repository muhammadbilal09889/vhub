'use client';
import { useState } from 'react';

export default function VStoreSell(){
  const [msg, setMsg] = useState('');
  async function submit(e: any){
    e.preventDefault();
    setMsg('Submitted! (Wire this form to /api/v-store/sell to save to DB)');
  }
  return (
    <main className="max-w-2xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Sell a Product</h1>
      <form onSubmit={submit} className="space-y-4 border rounded-2xl p-6 bg-white">
        <div>
          <label className="block text-sm font-medium">Product Name</label>
          <input required className="mt-1 w-full border rounded-xl p-2" name="name" placeholder="e.g., Lip Gloss" />
        </div>
        <div>
          <label className="block text-sm font-medium">Price (PKR)</label>
          <input required type="number" className="mt-1 w-full border rounded-xl p-2" name="price" placeholder="1500" />
        </div>
        <div>
          <label className="block text-sm font-medium">Description</label>
          <textarea className="mt-1 w-full border rounded-xl p-2" name="desc" rows={4} placeholder="Short details..." />
        </div>
        <button className="px-4 py-2 rounded-xl btn-brand" type="submit">Submit</button>
        {msg && <p className="text-green-700 text-sm mt-2">{msg}</p>}
      </form>
      <p className="text-xs text-gray-500">* This is a UI-only form. We can connect it to Prisma later.</p>
    </main>
  );
}
