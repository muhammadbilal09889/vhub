export const BRAND = {
  name: 'V Hub',
  shortName: 'VHub',
  description: 'V Hub — binary plan platform with real products/services, secure payouts, and KYC.',
  url: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
  colors: { primary: '#6D28D9', primaryDark: '#5B21B6', accent: '#10B981' },
  features: [
    { title: 'Secure Payouts', desc: 'JazzCash/Easypaisa HMAC verification, ledger-based accounting.' },
    { title: 'Member Growth', desc: '2-leg binary tree with level payouts and daily/lifetime caps.' },
    { title: 'KYC & Compliance', desc: 'CNIC uploads, admin review, and audit-ready records.' },
    { title: 'Bilingual UI', desc: 'Urdu + English toggle for wider reach.' },
  ],
  pricing: [
    { name: 'Starter', price: 'Rs. 300 join', bullets: ['Invite-only signup', 'Binary tree access', 'Member dashboard'] },
    { name: 'Pro', price: 'Rs. 300 + Add-ons', bullets: ['Reports & analytics', 'Priority support', 'Advanced referral tools'] }
  ]
} as const;
