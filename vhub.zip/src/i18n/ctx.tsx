'use client';
import React, { createContext, useContext, useMemo, useState } from 'react';
import { dict, type Lang } from './dict';

const I18nCtx = createContext<{ lang: Lang; t: (k: keyof typeof dict['en']) => string; setLang: (l:Lang)=>void }>({
  lang:'ur', t: (k:any)=>dict['ur'][k], setLang: ()=>{}
});

export function I18nProvider({ children }:{ children: React.ReactNode }){
  const [lang, setLang] = useState<Lang>('ur');
  const t = (k: keyof typeof dict['en']) => (dict as any)[lang][k] || (dict as any)['en'][k] || String(k);
  const value = useMemo(()=>({ lang, t, setLang }), [lang]);
  return <I18nCtx.Provider value={value}>{children}</I18nCtx.Provider>;
}

export function useI18n(){ return useContext(I18nCtx); }
