import { prisma } from './db';
export async function getAvailableBalance(userId: string){
  const commissions = await prisma.transaction.aggregate({ _sum:{ amount:true }, where:{ userId, type:'COMMISSION', status:'SUCCESS' } });
  const withdrawals = await prisma.transaction.aggregate({ _sum:{ amount:true }, where:{ userId, type:'WITHDRAWAL', status:'SUCCESS' } });
  const earned = commissions._sum.amount || 0;
  const paidOut = withdrawals._sum.amount || 0;
  return Math.max(0, earned - paidOut);
}
