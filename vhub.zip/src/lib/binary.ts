import { prisma } from './db';

export async function placeMember({ sponsorId, side, newUserId }:{ sponsorId:string; side:'left'|'right'; newUserId:string; }){
  const parent = await prisma.user.findUnique({ where:{ id: sponsorId } });
  if (!parent) throw new Error('Parent nahi mila');
  if (side === 'left'){
    if (parent.leftChildId) throw new Error('Left slot filled hai');
    await prisma.user.update({ where:{ id: sponsorId }, data:{ leftChildId: newUserId } });
  } else {
    if (parent.rightChildId) throw new Error('Right slot filled hai');
    await prisma.user.update({ where:{ id: sponsorId }, data:{ rightChildId: newUserId } });
  }
}

export async function computeEarningsFor(userId: string){
  const settings = await prisma.payoutSetting.findUnique({ where:{ id:1 } });
  const payouts: number[] = (settings?.perLevelPayouts as any) ?? [100,50,25,10,5];
  const dailyCap = settings?.dailyCap ?? 5000;
  const lifetimeCap = settings?.lifetimeCap ?? 50000;

  const queue: Array<{ id: string, depth: number }> = [{ id: userId, depth: 0 }];
  const perLevelCount: number[] = [];
  while(queue.length){
    const { id, depth } = queue.shift()!;
    const u = await prisma.user.findUnique({ where:{ id } });
    if (!u) continue;
    if (!perLevelCount[depth]) perLevelCount[depth] = 0;
    perLevelCount[depth]++;
    if (u.leftChildId) queue.push({ id: u.leftChildId, depth: depth+1 });
    if (u.rightChildId) queue.push({ id: u.rightChildId, depth: depth+1 });
  }
  const incomePerLevel = perLevelCount.map((count, i)=> (i===0 ? 0 : (payouts[i-1] || 0) * count));
  const gross = incomePerLevel.reduce((a,b)=>a+b,0);
  const lifetimeEarned = await prisma.transaction.aggregate({ _sum:{ amount:true }, where:{ userId, type: 'COMMISSION', status: 'SUCCESS' } });
  const lifetimeRemaining = Math.max(0, lifetimeCap - (lifetimeEarned._sum.amount || 0));
  const afterLifetime = Math.min(gross, lifetimeRemaining);
  const afterDaily = Math.min(afterLifetime, dailyCap);
  return { total: afterDaily, perLevel: incomePerLevel };
}
