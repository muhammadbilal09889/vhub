import { prisma } from './db';

/**
 * Credit a percentage of baseAmount (PKR) to user wallet as COMMISSION.
 * Defaults to 10%.
 */
export async function creditCommissionPKR(userId: string, baseAmountPKR: number, source: string, percent = 10){
  const commission = Math.round((baseAmountPKR || 0) * (percent/100));
  if (commission <= 0) return null;
  return prisma.transaction.create({
    data: {
      userId,
      type: 'COMMISSION',
      status: 'SUCCESS',
      amount: commission,
      meta: { source, baseAmountPKR, percent }
    }
  });
}
