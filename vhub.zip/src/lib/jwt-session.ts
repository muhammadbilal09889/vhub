import { verifyJwt } from '@/src/lib/auth';
export function getUserIdFromAuthHeader(headers: Headers): string | null {
  const bearer = headers.get('authorization') || '';
  const token = bearer.replace('Bearer ', '');
  const payload = verifyJwt<{ sub: string }>(token);
  return payload?.sub || null;
}
