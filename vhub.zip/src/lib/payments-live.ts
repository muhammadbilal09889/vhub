import CryptoJS from 'crypto-js';

export type JazzCashParams = {
  pp_Version: string;
  pp_TxnType: string;
  pp_Language: string;
  pp_MerchantID: string;
  pp_SubMerchantID?: string;
  pp_Password: string;
  pp_TxnRefNo: string;
  pp_Amount: string;
  pp_TxnCurrency: string;
  pp_TxnDateTime: string;
  pp_BillReference: string;
  pp_Description: string;
  pp_ReturnURL: string;
  pp_SecureHash?: string;
};

export function signJazzCash(p: JazzCashParams, integritySalt: string){
  const ordered = [
    p.pp_Version, p.pp_TxnType, p.pp_Language, p.pp_MerchantID,
    p.pp_SubMerchantID || '', p.pp_Password, p.pp_TxnRefNo, p.pp_Amount,
    p.pp_TxnCurrency, p.pp_TxnDateTime, p.pp_BillReference, p.pp_Description, p.pp_ReturnURL
  ].join('&');
  const hash = CryptoJS.HmacSHA256(ordered, integritySalt).toString();
  return { ...p, pp_SecureHash: hash } as JazzCashParams;
}

export type EasypaisaParams = {
  storeId: string;
  amount: string;
  orderRef: string;
  postBackURL: string;
  expiry: string;
  autoRedirect?: string;
  signature?: string;
};

export function signEasypaisa(p: EasypaisaParams, secret: string){
  const entries = Object.entries(p).filter(([k])=>k!=='signature').sort(([a],[b])=>a.localeCompare(b));
  const qs = entries.map(([k,v])=>`${k}=${v}`).join('&');
  const sig = CryptoJS.HmacSHA256(qs, secret).toString();
  return { ...p, signature: sig } as EasypaisaParams;
}
