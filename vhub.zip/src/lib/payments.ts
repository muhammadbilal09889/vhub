import CryptoJS from 'crypto-js';

export function verifyJazzCashSignature(payload: Record<string,string>): boolean {
  const salt = process.env.JAZZCASH_INTEGRITY_SALT!;
  const toSign = [
    payload.pp_Version,
    payload.pp_TxnType,
    payload.pp_Language,
    payload.pp_MerchantID,
    payload.pp_SubMerchantID || '',
    payload.pp_Password,
    payload.pp_TxnRefNo,
    payload.pp_Amount,
    payload.pp_TxnCurrency,
    payload.pp_TxnDateTime,
    payload.pp_BillReference,
    payload.pp_Description,
    payload.pp_ReturnURL,
  ].join('&');
  const expected = CryptoJS.HmacSHA256(toSign, salt).toString();
  return expected == payload.pp_SecureHash;
}

export function verifyEasypaisaSignature(payload: Record<string,string>): boolean {
  const secret = process.env.EASYPAISA_SECRET!;
  const keys = Object.keys(payload).filter(k=>k!=='signature').sort();
  const qs = keys.map(k=>`${k}=${payload[k]}`).join('&');
  const expected = CryptoJS.HmacSHA256(qs, secret).toString();
  return expected == payload.signature;
}
